/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pizzatestedrive;

/**
 *
 * @author Alunos
 */
public class PepperoniPizza extends Pizza{
     public PepperoniPizza () {
    name= "NY Style Sauce and Cheese Pizza";
    dough= "Thin Crust Dough";
    sauce = "Marinara Sauce";
    toppings.add("Grated Reggiano Cheese");
}
}
